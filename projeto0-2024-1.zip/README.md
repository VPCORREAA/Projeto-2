#Gerenciador de Tarefas
Este é um programa simples em C para gerenciar tarefas. Ele permite que você crie, liste, delete e salve  tarefas a partir de um arquivo.
Para utilizar execute o main.c em ./src


                                               Funcionalidades


•Criar Tarefa: Adiciona uma nova tarefa com uma prioridade, categoria e descrição especificadas pelo usuário.


•Deletar Tarefa: Remove uma tarefa existente com base em sua posição na lista.


•Listar Tarefas: Exibe todas as tarefas ou aquelas pertencentes a uma categoria específica.


•Salvar Tarefas: Salva todas as tarefas em um arquivo especificado pelo usuário.


•Carregar Tarefas: Carrega tarefas de um arquivo especificado pelo usuário.